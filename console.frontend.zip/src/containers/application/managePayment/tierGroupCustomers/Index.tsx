"use strict";

import * as React from "react";

interface IIndexProps {

}

interface IIndexState {

}

class Index extends React.Component<IIndexProps, IIndexState> {
    render(): JSX.Element  {
        return (
            <div>
                Customers
            </div>
        );
    }
}

export default Index;
