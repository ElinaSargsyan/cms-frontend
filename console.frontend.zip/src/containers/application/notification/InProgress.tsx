"use strict";


import * as React from "react";

interface IInProgressProps {
}

interface IInProgressState {
}

class InProgress extends React.Component<IInProgressProps, IInProgressState> {
    render(): JSX.Element {
        return(
            <div>
                InProgress
            </div>
        )
    }
}

export default InProgress;
