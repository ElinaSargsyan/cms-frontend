"use strict";


import * as React from "react";
interface IDraftsProps {
}

interface IDraftsState {
}

class Drafts extends React.Component<IDraftsProps, IDraftsState> {
    render(): JSX.Element {
        return(
            <div>
                Drafts
            </div>
        )
    }
}

export default Drafts;
